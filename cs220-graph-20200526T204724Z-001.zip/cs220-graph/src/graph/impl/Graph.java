package graph.impl;

import java.util.Collection;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Queue;
import java.util.Stack;
import java.util.PriorityQueue; 
import java.util.Set;

import graph.IGraph;
import graph.INode;
import graph.NodeVisitor;

/**
 * A basic representation of a graph that can perform BFS, DFS, Dijkstra,
 * and Prim-Jarnik's algorithm for a minimum spanning tree.
 * 
 * @author jspacco
 *
 */
public class Graph implements IGraph
{

    HashMap<String, Node> nodes;

    public Graph()
    {
        this.nodes = new HashMap<String, Node>();
    }
    
    /**
     * Return the {@link Node} with the given name.
     * 
     * If no {@link Node} with the given name exists, create
     * a new node with the given name and return it. Subsequent
     * calls to this method with the same name should
     * then return the node just created.
     * 
     * @param name
     * @return
     */
    public INode getOrCreateNode(String name) {
        
        if !(this.nodes.containsKey(name))
        {
            INode newNode = new Node(name);
        }

        this.nodes.put(name, newNode);
        return this.nodes.get(name);
    }

    /**
     * Return true if the graph contains a node with the given name,
     * and false otherwise.
     * 
     * @param name
     * @return
     */
    public boolean containsNode(String name) {
        return this.containsKey(name);
    }

    /**
     * Return a collection of all of the nodes in the graph.
     * 
     * @return
     */
    public Collection<INode> getAllNodes() {
        return new ArrayList<Inode>(this.nodes.values());
    }
    
    /**
     * Perform a breadth-first search on the graph, starting at the node
     * with the given name. The visit method of the {@link NodeVisitor} should
     * be called on each node the first time we visit the node.
     * 
     * 
     * @param startNodeName
     * @param v
     */
    public void breadthFirstSearch(String startNodeName, NodeVisitor v)
    {

        Set<String> visited = new HashSet<String>();
        Queue<Node> q = new LinkedList<Node>();
        startNode = (Node)this.getOrCreateNode(startNodeName);

        visited.add(startNode);
        q.add(startNodeName);
        v.visit(startNode);

        while !(q.isEmpty())
        {
            Node currNode = q.remove();
            v.visit(currNode);

            for (Inode nei: currNode.getNeighbors())
            {
                if !(visited.contains(nei.getName()))
                {
                    q.add(Node(nei))
                    visited.add(nei.getName());
                }
            }
        }
        
    }

    /**
     * Perform a depth-first search on the graph, starting at the node
     * with the given name. The visit method of the {@link NodeVisitor} should
     * be called on each node the first time we visit the node.
     * 
     * 
     * @param startNodeName
     * @param v
     */
    public void depthFirstSearch(String startNodeName, NodeVisitor v)
    {
        Set<String> visited = new HashSet<String>();
        Stack<Node> stack = new Stack<Node>();
        startNode = (Node)this.getOrCreateNode(startNodeName);

        visited.add(startNode);
        stack.add(startNodeName);
        v.visit(startNode);

        while !(stack.isEmpty())
        {
            Node currNode = stack.remove();
            v.visit(currNode);

            for (Inode nei: currNode.getNeighbors())
            {
                if !(visited.contains(nei.getName()))
                {
                    stack.add((Node)nei)
                    visited.add(nei.getName());
                }
            }
        }
        
    }

    /**
     * Perform Dijkstra's algorithm for computing the cost of the shortest path
     * to every node in the graph starting at the node with the given name.
     * Return a mapping from every node in the graph to the total minimum cost of reaching
     * that node from the given start node.
     * 
     * <b>Hint:</b> Creating a helper class called Path, which stores a destination
     * (String) and a cost (Integer), and making it implement Comparable, can be
     * helpful. Well, either than or repeated linear scans.
     * 
     * @param startName
     * @return
     */
    public Map<INode,Integer> dijkstra(String startName) {
        
        PriorityQueue<Path> priorityQ = new PriorityQueue<Path>();
        HashMap<INode, Integer> shortestDistance = new HashMap<INode, Integer>();
        Set<String> visited = new HashSet<String>();

        for (INode curr: this.nodes.keySet())
        {
            shortestDistance.put(curr.getName(), Integer.MAX_VALUE);
        }

        shortestDistance.put(startName, 0);

        priorityQ.add(new Path(getOrCreateNode(startName), 0));

        while !(priorityQ.isEmpty())
        {
            Path currNodeName = priorityQ.poll();
            Node currNode = this.nodes.getOrCreateNode(currNodeName);
            int currNodeCost = currNode.cost;
            visited.add(currNodeName);

            for (INode nextNode: currNode.getNeighbors())
            {
                int newDistance = currNodeCost + currNode.getWeight(nextNode);
                String nextNodeName = nextNode.getName();

                if (newDistance < shortestDistance.get(nextNodeName) && !(visited.contains(nextNode)))
                {
                    shortestDistance.put(nextNodeName, newDistance);
                    priorityQ.add(new Path(getOrCreateNode(nextNodeName), newDistance));
                }
            }

        }

    }
    
    /**
     * Perform Prim-Jarnik's algorithm to compute a Minimum Spanning Tree (MST).
     * 
     * The MST is itself a graph containing the same nodes and a subset of the edges 
     * from the original graph.
     * 
     * @return
     */
    public IGraph primJarnik() {
        //TODO Implement this method
        throw new UnsupportedOperationException();
    }
}